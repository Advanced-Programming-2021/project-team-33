package View;

public class ShopMenu {
}
