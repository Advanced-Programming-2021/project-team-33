package View;

public class MainMenu {

    public void run() {

    }

}
