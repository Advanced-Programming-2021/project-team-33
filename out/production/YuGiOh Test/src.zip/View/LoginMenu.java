package View;

public class LoginMenu {

    public void run() {

    }

    public void register() {

    }

    public void login() {

    }

}

