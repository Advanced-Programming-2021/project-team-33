package View;

public class ScoreboardMenu {
}
