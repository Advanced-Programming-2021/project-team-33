package Model;

public class Board {
}
