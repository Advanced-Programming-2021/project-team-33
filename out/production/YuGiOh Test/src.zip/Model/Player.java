package Model;

public class Player {
}
