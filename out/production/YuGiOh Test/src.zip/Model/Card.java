package Model;

public class Card {
}
