package Model;

public class Deck {
}
